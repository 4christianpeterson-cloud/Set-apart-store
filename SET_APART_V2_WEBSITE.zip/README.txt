SET APART V2
============

This is a real static storefront starter:
- public homepage/shop
- six products
- category filters
- product size selection
- working browser cart with localStorage
- responsive/mobile layout
- manager page
- lightweight editable SVG launch artwork

PUBLIC HOSTING
--------------
GitHub Pages can publish static HTML/CSS/JS files from a GitHub repository.
Cloudflare Pages can also deploy a static HTML site.

COLLABORATION
-------------
For shared code/content changes, use a GitHub repository and give collaborators
the appropriate repository role. Do not share passwords or tokens.

IMPORTANT
---------
The checkout button is intentionally not connected to a payment processor yet.
A guardian should create/manage the merchant/payment account. Once you have the
provider chosen, the checkout flow can be connected.

EDITING
-------
Open index.html in a code editor. Product data is in the PRODUCTS array.
For an easier non-technical editor, the next version should connect the store
to a CMS/database while keeping the public site static.
